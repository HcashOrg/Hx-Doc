## HX Smart Conctract IDE

IDE is mostly used for writing and translating contract and on-chain registration, debug functionality will be added in the future. 

The main functions are briefly described below:

* uvlua/java/c#/kotlin can be used when writing contract on IDE, it provides functionalities such as code association, templates and etc.（For example, newtoken contract template）
* IDE helps user to write and translate languages within a finger tap, which makes it much more convenient to generate contract into bytecode. 
* IDE uses file system to manage contracts, you can easily manage many original files there and displayed as file system form in IDE. 
* Backstage offers official chains and corresponding testing chains of CTC, UB, HX and etc, which can realizes part of functionalities of the wallet of each chain, such as account management, registration and transaction.  
* IDE support contract release. User can release smart contract onto the chain after successfully testing it in a test environment. 
* It manages registered contracts and allows users to review registered contacts. 
