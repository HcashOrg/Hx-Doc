# HX-Indicator Usage Q/A

Q：HX-Indicator how to upgrade

A：At left bottom, click "Help" -> "software update", click to check the update, if there is a new version of the release, it will be automatically downloaded, click the update immediately, then automatically restart the wallet, the wallet interface will be displayed after success.

Q：When upgrading, click update now and keep reminding that the wallet is closing or loading

A：If the wait time is long, open the task manager and end the processhx_node.exe/hx_cli.exe/HXIndicator.exe, Download the latest version from the official website, locate the HXIndicator.exe file and double-click it. After success, you will be prompted to enter your wallet password.

Q：When starting HXIndicator.exe, if shows loading a long time or prompt failed to start hx_node.exe

A：If loading is still displayed, open the task manager, end the process hx_node.exe, hx_cli.exe, HXIndicator.exe, find the data path of hx, move the `blockchain` folder to the recycle bin, and do not delete other files.

Q：The prompt block cannot be synchronized

A：Click the time in the lower right corner of the computer, find the Internet time -> change Settings -> immediately update, re-open the HXIndicator.exe, start synchronization.

Q：How long does HC recharge arrive in the account

A：Normally, you need 8 blocks confirm to Tunnel account, and then "allot" and wait for 4 blocks confirm to go to the HX chain.

Q：Contract registration prompt failed

A：Take note that the HXIndicator.exe path cannot contain Chinese.