## Contacts

Click the icon on the top right corner to add a contact,input "ADDRESS" and "REMARK NAME",select "GROUP",click "Ok".

![Contacts](/img/wallets/hxindicator/contact-add.png)

![Contacts](/img/wallets/hxindicator/contact-show.png)

If you want to edit the group or contact,Select on the left and right click.

![Contacts](/img/wallets/hxindicator/contact-edit.png)

![Contacts](/img/wallets/hxindicator/contact-edit1.png)

---
