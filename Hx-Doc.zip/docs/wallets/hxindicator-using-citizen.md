## Citizen Account Info

> Citizen Account Info

Select a citizen account, will show detail information of this citizen.

![Citizen Account Info](/img/wallets/hxindicator/citizen-account-info.png)

> Create New Citizen

Click botton "CREATE CITIZEN",select an account,click "Ok",then input password of the account(it spent 1000HX).

![Citizen Account Info](/img/wallets/hxindicator/citizen-create.png)

![Citizen Account Info](/img/wallets/hxindicator/citizen-create1.png)

![Citizen Account Info](/img/wallets/hxindicator/citizen-create2.png)

> Start Mining

Click "START MINING" to start mining, then need to restart hx-indicator.

![Citizen Account Info](/img/wallets/hxindicator/citizen-start-mining.png)

![Citizen Account Info](/img/wallets/hxindicator/citizen-start-mining1.png)

> Change Fee

Click "CHANGE FEE", select "Account", input"Change to(%)", click OK.

![Citizen Account Info](/img/wallets/hxindicator/citizen-change-fee.png)

![Citizen Account Info](/img/wallets/hxindicator/citizen-change-fee1.png)

![Citizen Account Info](/img/wallets/hxindicator/citizen-change-fee2.png)

## Citizen Proposal

Select "CURRENT CITIZEN",you will find all proposals of this account.

![Citizen Info](/img/wallets/hxindicator/citizen-proposal.png)

Change Senator Proposal

Click "CHANGE SENATOR", select "Proposer", select "Nomination List(Three Nomination At Most)", it spent 1000 hx at least.

![Citizen Info](/img/wallets/hxindicator/citizen-proposal1.png)

---