## Account

> Senator Account Info

Select "CURRENT SENATOR",will show information about it.

![Senator](/img/wallets/hxindicator/senator-account-info.png)

Click "NEW SENATOR" to create a new senator(it spent 10000hx)，input account password.

![Senator new](/img/wallets/hxindicator/senator-new.png)

![Senator new](/img/wallets/hxindicator/senator-new1.png)

![Senator new](/img/wallets/hxindicator/senator-new2.png)

> My Income

Citizen will distribute partial income to senator.

## Proposal

> Proposal

Select "CURRENT SENATOR",will show all type proposal of this account.you can click on the "TYPE(CLICK)" to see detail infomation about each proposal.

![Proposal](/img/wallets/hxindicator/proposal.png)

Click "approve" or "disapprove" to vote,then the "VOTING STATE" and "MY VOTE" will change accordingly.

![Proposal](/img/wallets/hxindicator/approve.png)

> Cold-Hot Trx

Click "CREATE",then select "Coin"/"Choose Account"/"hot address to cold",input "Amount"/"Expiration(s)",click "Ok".

![Cold-Hot Trx](/img/wallets/hxindicator/create-cold-hot-tx.png)

![Cold-Hot Trx](/img/wallets/hxindicator/create-cold-hot-tx1.png)

If are eth or erc20 assets,after "CONFIRMING", need do sign operator,please click "ETH-SIGN",,then click "sign"

![Cold-Hot Trx](/img/wallets/hxindicator/create-cold-hot-tx2.png)

![Cold-Hot Trx](/img/wallets/hxindicator/create-cold-hot-tx3.png)

> Withdraw

Select "CURRENT SENATOR",will show all withdraw record of this account.then click "check"/"sign".

![Withdraw](/img/wallets/hxindicator/authorized-withdraw.png)

If are eth or erc20 assets,after "CONFIRMING", need do sign operator,please click "ETH-SIGN",then click "sign"

![Withdraw](/img/wallets/hxindicator/authorized-withdraw1.png)

![Withdraw](/img/wallets/hxindicator/authorized-withdraw2.png)

> Market Price

Select "CURRENT SENATOR",will show all currency feed price of this account.if you want to change feed price,click "feed",then input "Price".

![Market Price](/img/wallets/hxindicator/martet-price.png)

## Advance

> Senator Key Management

Show current all assets's HOT and COLD MULTISIG-ADDRESS.If you want to change the hot-cold multi-sign address,steps as below:
* Click "IMPORT",import private keys of all guards;
* Click "CHANGE M-A",to change HOT-COLD address,then it will create a proposal;
* Select just created proposal in "PROPOSAL",to vote;
* After voting,click "update".

![Senator Key Management](/img/wallets/hxindicator/senator-key-manage.png)

Click "HISTORY",it will display the multi-sign addresses change history.

![Senator Key Management](/img/wallets/hxindicator/senator-key-manage-history.png)

> Asset Info

Show all assets info.

![Asset Info](/img/wallets/hxindicator/senator-asset-info.png)

---
