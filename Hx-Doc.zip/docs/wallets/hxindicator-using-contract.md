There are include Exchange Contract and Standard Contract.In Exchange Contract you can buy and sell each other's assets;In Standard Contract you can register and deploy standard contract. 

## Exchange Contract

> Orders Center

All types of transaction are listed in this page.

![Orders Center](/img/wallets/hxindicator/order-center.png)

If you want to buy other types of currency,select record,click "buy",then input "Amount",click "Ok".

![Orders Center](/img/wallets/hxindicator/order-center-buy.png)

> My Orders

Click "CREATECONTRACT" to create a new exchange contract.This operation can be done only one time.

![My Orders](/img/wallets/hxindicator/myorders-create-contract.png)

![My Orders](/img/wallets/hxindicator/myorders-create-contract1.png)

Click "MY CONTRACT",you can see the contract address just has been created.Then click "DEPOSIT",select "Coin" which have enough balance,input "Deposit amount" and "Password",click "Ok".

![My Orders](/img/wallets/hxindicator/myorders-contract-balance.png)

![My Orders](/img/wallets/hxindicator/myorders-contract-deposit.png)

![My Orders](/img/wallets/hxindicator/myorders-contract-deposit1.png)

This record can be found in "Contract Balance".

![My Orders](/img/wallets/hxindicator/myorders-contract-balance1.png)

If you want to withdraw,please click "withdraw",then select "Coin to withdraw",input "Amount to withdraw" and "Password",click "Ok". 

![My Orders](/img/wallets/hxindicator/myorders-contract-withdraw.png)

If you want to exchange your asset to another type of currency,click "SELL",select currency type that you would like to exchange,input "SellAmount"/"BuyAmount" and "Password",click "Ok".

![My Orders](/img/wallets/hxindicator/myorders-contract-sell.png)

![My Orders](/img/wallets/hxindicator/myorders-contract-sell1.png)

The record can be found in "My Orders",you can "cancel" or "add" anytime.

## Standard Token Contract

> Click "CREATE TOKEN" to create a new contract.Select account name,click "REGISTER".

![Standard Token Contract](/img/wallets/hxindicator/contract-create-token.png)

![Standard Token Contract](/img/wallets/hxindicator/contract-create-token1.png)

Input "Token Name"/"Token Symbol"/"Total supply",select "Precision",click "INITIALIZE".

![Standard Token Contract](/img/wallets/hxindicator/contract-create-token2.png)

![Standard Token Contract](/img/wallets/hxindicator/contract-create-token3.png)

> Click "ADD TOKEN",input "Contract Address",click "Add",a new token will be added.list in page "Standard Token".

![Standard Token Contract](/img/wallets/hxindicator/contract-add-token.png)

> Click "RECORD",then select token,will show the transaction id related to this token.

![Standard Token Contract](/img/wallets/hxindicator/contract-record.png)

---
