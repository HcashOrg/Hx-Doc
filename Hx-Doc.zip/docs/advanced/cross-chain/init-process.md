1). After the initialisation of the HyperExchange network, an initial asset allocation and basic parameter configuration will be performed.
		
2). After reaching consensus on the HyperExchange, a Senator creates multi-signature accounts for BTC, LTC, and other blockchains. Those addresses are then signed and controlled by all Senators and broadcasted throughout the network.				

3). Each Senator pays a margin amount specified by the HCASH Foundation to be used for ensuring chain stability.
