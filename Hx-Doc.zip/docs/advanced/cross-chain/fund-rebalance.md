A dynamic fund rebalancing process is conducted every 10,000 blocks, with the total amount of assets within a multi-signature hot wallet adjusted to a specified range.
					
This rebalancing transaction is then created by the Citizen who generated the block. This transaction will need to be signed by 2/3 of all Senators and then be broadcasted through the network.
