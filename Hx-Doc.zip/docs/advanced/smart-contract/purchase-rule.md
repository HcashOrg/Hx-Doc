*	Pending purchase orders utilise smart contracts.
*	Pending purchase orders are able to be partially filled.	
*	Pending purchase orders are able to be cancelled.		
*	The matching deal and the withdrawal of the pending order are both transactions conducted through smart contracts.	
*	Buying pending orders, matching pending orders, and cancelling purchases all incur fees.

Figure: Pending purchase orders
<img class="hx-icon" src="/img/pending-pur.svg" />