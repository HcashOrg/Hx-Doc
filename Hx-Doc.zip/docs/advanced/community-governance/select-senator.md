1.Total amount of Senators is 15 fixed, not less, not more, but replaceable. 

2.15 Senators are divided into two parts with entirely same rights, however, replacement methods are different. 

- 5 permanent Senators, which are entitled to initiate replacement.
- 10 campaign senators on selection board, any random citizen can initiate a proposal of replacement, and proceed replacement after all Citizens voting. 

3.It remains 15 senators to governance the community after replacement. 
