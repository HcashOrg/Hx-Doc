Senators are responsible for the ongoing management of the HyperExchange chain. Their duties include modifying parameters and processing fees through consensus, changing the minimum amount of required pledged assets from Citizens
. 
Senators are responsible for the management of cross-chain assets. They manage these by creating hot and cold multi-signature wallets, with withdrawals not being approved until at least 2/3 of Senators reach consensus.

Senators will receive 20% of contractual withdrawal fees and 30% of block rewards.

