Senators manage assets and govern communities through a consensus mechanism. Citizens use that consensus mechanism to vote on whether or not to replace a Senator. The interests of the two parties are aligned and they maintain each other, ensuring optimal network security and stability.

The solution of keeping 5 permanent Senators prevents the possibility of intentionally withdraw cross-chain assets by controlling more 2/3 Senators through voting mechanism.

The interests of Senators are closely related to the interests of the community. Senators are rewarded with incentives and benefits provided through the HyperExchange ecosystem.