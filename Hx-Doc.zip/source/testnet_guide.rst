HX Testnet Guide
================