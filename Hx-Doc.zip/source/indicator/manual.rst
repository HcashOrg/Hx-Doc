Indicator Manual
================