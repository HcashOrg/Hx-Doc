.. HX Document documentation master file, created by
   sphinx-quickstart on Fri Aug 10 17:15:58 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to HyperExchange's documentation!
=========================================

.. toctree::
   :maxdepth: 2
   :numbered:
   :glob:
   :caption: Contents:

   hx_deployment
   hxcore/cli_reference
   indicator/manual
   testnet_guide

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
