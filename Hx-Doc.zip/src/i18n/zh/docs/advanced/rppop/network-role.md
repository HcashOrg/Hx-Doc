在 HyperExchange 生态中有四种角色： Tourist、Candidate ofCitizen、Citizen、Senator。

---

## Tourist

包括 HyperExchange 链上的所有用户以及与 HyperExchange 互通的其他链上的所有用户。

---

## Citizen

Citizen 是 HyperExchange 的生产者和社区治理者，负责记账和产块，它是链上的去中心化矿池。Candidate of Citizen 成为 Citizen 需
要提供链上多资产质押（HSR/HC 会获得较高的权重），可以自己提供，也可以由其他用户支持提供。

---

## Senator

Senator是HyperExchange生态中的资产管理者和社区治理者。Senator 负责共识管理其他资产链上的多重签名冷热地址里的资产，并且各资产链之间的资产流通必须通过 Senator 的共识来达成。Senator总数固定为15个，可以更替，不可增减，分为5个安全Senator和10个竞选Senator，安全Senator更替只由这5个Senator投票来确定，竞选Senator的更替要通过Citizen的投票来确定。

---

