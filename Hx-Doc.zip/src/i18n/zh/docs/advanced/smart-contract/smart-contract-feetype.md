
![Fee-type](/img/advanced/fee-type.png)
