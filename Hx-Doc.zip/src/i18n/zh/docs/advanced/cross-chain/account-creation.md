## 账户的创建

为了完成跨链转账，Tourist 需要在 Indicator 上创建 HyperExchange账户，Indicator 会提供隧道账户创立选项，并与 HyperExchange 账户进行绑定。当资产链（比如 BTC）往多重签名账户充值的时候，HyperExchange 在确认后会将等量的 HIOU 发放到绑定的 HyperExchange 账户上。

在 整 个 HyperExchange 初 始 化 或 者 是 有 新 的 Senator 加入HyperExchange 网络的时候，需要在资产链(BTC,LTC 等)创建或更新多重签名账户。账户类型包括：

1 、HyperExchange  账户
用户首先需要创建一个 HyperExchange 账户，用于存储、交易HyperExchange 上的多种资产，包括 HIOU、HX 等。

2 、隧道账户
当用户在 HyperExchange 中创建账户时，HyperExchange 会根据隧道协议生成对应的隧道账户，并与 HyperExchange 账户绑定。隧道账户绑定
HyperExchange 账户每日免费限额 1 万笔，超出限额需 Citizen 审核。（1 万可共识修改）

3 、多重签名冷热 钱包
跨链资产将会保存在由 Senator 共识创建和管理的各个资产链上的多重签名冷热钱包里。