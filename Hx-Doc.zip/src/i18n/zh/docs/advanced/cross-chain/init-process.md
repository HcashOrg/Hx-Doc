初始化流程

* 初始化 HyperExchange，进行初始资产分配，基本参数配置。
* HyperExchange 上 Senator 通过共识在 BTC、LTC 等资产链上分别创建多重签名账户，并把多重签名账户的地址由所有 Senator 签名后广播到 HyperExchange 上。
* 每个 Senator 交纳 HCASH 基金会规定的责任保证金，用于维护链的稳定。