Blockchain Multi Tunnel Protocol （ 区 块 链 多 隧 道 协 议 ） 是HyperExchange 独创的用于区块链间点对点信息传输的通讯协议。
当用户在 HyperExchange 中创建账户时，HyperExchange 会根据Blockchain Multi Tunnel Protocol 生成对应的隧道账户，并与HyperExchange账户绑定。当发生跨链交易时，通过Blockchain Multi TunnelProtocol 将相应数据进行封装打包安全传递。

Blockchain Multi Tunnel Protocol 产生的隧道账户可以帮助HyperExchange 确认转入资产的唯一对应性。Blockchain Multi Tunnel
Protocol 只承认通过隧道账户进行跨链交易的资产，并根据共识生成或销毁对应的 HIOU 资产代币。