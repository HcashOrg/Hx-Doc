1.Senator总数固定为15个，可以更替，不可增减

2.15个Senator分为两部分，其权利完全一致，但更替方式有所不同：

- 5个安全Senator，只由这5个Senator发起更替
- 10个竞选Senator，由任一Citizen发起提案，经过全体Citizen投票进行更替

3.更替完成后仍然保持15个Senator进行社区自治
