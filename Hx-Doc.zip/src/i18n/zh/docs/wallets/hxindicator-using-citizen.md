## Citizen账户信息

> Citizen Account Info

选择一个citizen账户，显示该citizen的详细信息。

![Citizen Account Info](/img/wallets/hxindicator/citizen-account-info.png)

> 创建新Citizen

点击按钮"CREATE CITIZEN",选择一个可用账户,点击 "确定",然后输入账户密码(需要消耗1000HX).

![Citizen Account Info](/img/wallets/hxindicator/citizen-create.png)

![Citizen Account Info](/img/wallets/hxindicator/citizen-create1.png)

![Citizen Account Info](/img/wallets/hxindicator/citizen-create2.png)

> 启动挖矿

点击"START MINING"按钮，开启挖矿，之后需要重启hx-indicator。

![Citizen Account Info](/img/wallets/hxindicator/citizen-start-mining.png)

![Citizen Account Info](/img/wallets/hxindicator/citizen-start-mining1.png)

> 更改矿池手续费

点击"CHANGE FEE"，选择"Account"，输入"Change to(%)"，点击OK。

![Citizen Account Info](/img/wallets/hxindicator/citizen-change-fee.png)

![Citizen Account Info](/img/wallets/hxindicator/citizen-change-fee1.png)

![Citizen Account Info](/img/wallets/hxindicator/citizen-change-fee2.png)

## Citizen提案

选择"当前CITIZEN账号",将会现在该账户下所有的提案.

![Citizen Info](/img/wallets/hxindicator/citizen-proposal.png)

更换Senator提案

点击"CHANGE SENATOR"，选择"Proposer"，选择更换名单"Nomination List(Three Nomination At Most)"，一次最多发起3个senator的替换，至少需要消耗1000HX。

![Citizen Info](/img/wallets/hxindicator/citizen-proposal1.png)

---