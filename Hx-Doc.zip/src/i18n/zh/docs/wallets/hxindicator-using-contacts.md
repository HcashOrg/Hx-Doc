## 联系人

点击右上角的图标新建一个联系人，输入"账户地址"和"备注名",选择"分组",点击 "确定".

![Contacts](/img/wallets/hxindicator/contact-add.png)

![Contacts](/img/wallets/hxindicator/contact-show.png)

如果你想编辑分组或者联系人，点击左边的列表。

![Contacts](/img/wallets/hxindicator/contact-edit.png)

![Contacts](/img/wallets/hxindicator/contact-edit1.png)

---
